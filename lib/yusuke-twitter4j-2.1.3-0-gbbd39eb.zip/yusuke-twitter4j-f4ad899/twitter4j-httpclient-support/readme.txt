Twittetr4J is a Twitter API binding library for the Java language licensed under the BSD license.

optional component adds Apache HttpClient support