Twittetr4J is a Twitter API binding library for the Java language licensed under the BSD license.

LICENSE.txt - the terms of license of this software
pom.xml - maven parent pom
powered-by-badge - badge
readme.txt - this file
twitter4j-apache-httpclient-support - optional component adds Apache HttpClient support
twitter4j-core - core component
twitter4j-examples - examples
